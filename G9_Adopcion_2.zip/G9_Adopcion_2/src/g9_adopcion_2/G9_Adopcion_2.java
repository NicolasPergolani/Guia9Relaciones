

package g9_adopcion_2;

//@author Your Name <Rodrigo Pereyra>

import g9_adopcion_2.Servicio.Adoptar;


public class G9_Adopcion_2 {

    public static void main(String[] args) {
        
     Adoptar ad = new Adoptar();
     
     
     ad.personas();
     ad.perros();
     ad.adoptar();
     ad.mostrar();
        
        
        
    }

}